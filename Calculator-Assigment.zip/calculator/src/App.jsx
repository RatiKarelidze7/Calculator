import { useState } from 'react'
import classes from "./Modules/App.module.scss"

function App() {

    const [input, setInput] = useState("")
    const [operation, setOperation] = useState(null)
    const [previusValue, setPreviusValue] = useState(null)

    const NumberClickHandler = (num) => {
        setInput((prev) => prev + num)
    }

    const operationHandler = (operat) => {
        setOperation(operat)
        setPreviusValue(parseFloat(input));
        setInput("")
    }

    const calculatorHandler = () => {
        const currentValue = parseFloat(input)
        let result
        switch (operation) {
            case "+":
                result = previusValue + currentValue;
                break;
            case "-":
                result = previusValue - currentValue;
                break;
            case "*":
                result = previusValue * currentValue;
                break;
            case "/":
                result = previusValue / currentValue;
                break;
            default:
                return;
        }

        setInput(result.toString())
        setOperation(null)
        setPreviusValue(null)
    };

    const clearHandler = () => {
        setInput("");
        setOperation(null);
        setPreviusValue(null);
    }

  return (
    <div className={classes['main']}>
      <div className={classes['calculator']}>
          <div className={classes['theme-zone']}>Calc</div>
          <div className={classes["anwser"]}>{input}</div>
          <div className={classes["num-buttons"]}>
              <button onClick={() => NumberClickHandler("7")}>7</button>
              <button onClick={() => NumberClickHandler("8")}>8</button>
              <button onClick={() => NumberClickHandler("9")}>9</button>
              <button onClick={clearHandler} className={classes["del-btn"]}>DEL</button>
              <button onClick={() => NumberClickHandler("4")}>4</button>
              <button onClick={() => NumberClickHandler("5")}>5</button>
              <button onClick={() => NumberClickHandler("6")}>6</button>
              <button onClick={() => operationHandler("+")}>+</button>
              <button onClick={() => NumberClickHandler("1")}>1</button>
              <button onClick={() => NumberClickHandler("2")}>2</button>
              <button onClick={() => NumberClickHandler("3")}>3</button>
              <button onClick={() => operationHandler("-")}>-</button>
              <button>.</button>
              <button onClick={() => NumberClickHandler("0")}>0</button>
              <button onClick={() => operationHandler("/")}>/</button>
              <button onClick={() => operationHandler("*")}>*</button>
              <button onClick={clearHandler} className={classes['reset-btn']}>RESET</button>
              <button onClick={calculatorHandler} className={classes['equality-btn']}>=</button>
          </div>
      </div>
    </div>
  )
}

export default App
